import axios from 'axios';

export const API = axios.create({
  baseURL: (import.meta.env.VITE_API_URL || '').replace(/\/+$/, ''),
  withCredentials: true, // keep if backend uses cookies
});
